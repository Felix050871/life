// Dashboard loading system - overlay completamente rimosso
// Solo feedback sui pulsanti per migliore UX senza interferenze
console.log('Dashboard loading: no overlay system - button feedback only');